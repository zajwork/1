template <class Type>
class MyDoublyLinkedList
{
private:
	Node *head;
	Node *tail;
public:
	LinkedList()
	{
		head = NULL;
		tail = NULL;
	}
	void insertAtFront(Type data)
	{
		Node *N = new Node;
		N->data = data;
		N->next = head;

		if (head == NULL)
		{
			tail = N;
		}
		head = N;

	}
	void insertAtEnd(Type data)
	{
		Node *N = new Node;
		N->data = data;
		N->next = NULL;

		if (head == NULL)
		{
			head = N;
			tail = N;
		}
		else
		{
			tail->next = N;
			tail = N;
		}
	}
	Type removeFromFront()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;

			if (head == tail)
			{
				head = tail = NULL;
				delete temp;
			}
			else
			{
				head = head->next;
				delete temp;
			}
		}
	}
	Type removeFromEnd()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;

			if (head == tail)
			{
				head = tail = NULL;
				delete temp;
			}
			else
			{
				while (temp->next != tail)
				{
					temp = temp->next;
				}
				tail = temp;
				temp = temp->next;
				delete temp;
				tail->next = NULL;
			}
		}
	}
	bool insertAt(int index, Type)
	{

	}
	bool Search(Type data)
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;

			if (head->data == data)
			{
				cout << "Data found!" << endl;
			}
			else if (tail->data == data)
			{
				cout << "Data found!" << endl;
			}
			else
			{
				Node* prev = head;
				Node* temp = prev->next;

				bool found = false;

				while (temp->next != NULL)
				{
					if (temp->data == data)
					{
						prev->next = temp->next;
						found = true;
						break;
					}

					prev = temp;
					temp = temp->next;
				}

				if (found == false)
				{
					cout << "Data not found" << endl;
				}
				else
				{
					cout << "Data found!" << endl;
				}
			}
		}
	}

		void Display()
		{
			if (head == NULL)
			{
				cout << "List is empty" << endl;
			}
			else
			{
				Node *temp = head;
				while (temp != NULL)
				{
					cout << temp->data << " ";
					temp = temp->next;
				}
			}
		}

	
};