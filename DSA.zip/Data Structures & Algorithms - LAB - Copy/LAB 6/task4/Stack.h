#include <iostream>
using namespace std;

template <class Type>
class Stack
{
private:
	Node *head;
	Node *tail;
public:
	Stack()
	{
		head = NULL;
		tail = NULL;
	}
	void push(Type data)
	{
		Node *N = new Node;
		N->data = data;
		N->next = NULL;

		if (head == NULL)
		{
			head = N;
			tail = N;
		}
		else
		{
			tail->next = N;
			tail = N;
		}
	}
	void pop()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;

			if (head == tail)
			{
				head = tail = NULL;
				delete temp;
			}
			else
			{
				while (temp->next != tail)
				{
					temp = temp->next;
				}
				tail = temp;
				temp = temp->next;
				delete temp;
				tail->next = NULL;
			}
		}
	}
	Type peek()
	{
		return tail;
	}
	void display()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;
			while (temp != NULL)
			{
				cout << temp->data << " ";
				temp = temp->next;
			}
		}
	}

};
