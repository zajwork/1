#include <iostream>
using namespace std;

template <class Type>
class Node
{
private:
	Type data;
	Node *next;
	Node *prev;
public:
	Node()
	{
		next = NULL;
		prev = NULL;
	}
	void setData(Type data)
	{
		this->data = data;
	}
	void setNext(Node* next)
	{
		this->next = next;
	}
	void setPrev(Node* prev)
	{
		this->prev = prev;
	}
	Type getData()
	{
		return data;
	}
	Node* getNext()
	{
		return next;
	}
	Node* getPrev()
	{
		return prev;
	}
};
