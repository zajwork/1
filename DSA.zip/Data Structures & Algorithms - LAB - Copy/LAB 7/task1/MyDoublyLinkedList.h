#include "DoublyLinkedList.h"

template <class Type>
class MyDoublyLinkedList : public <Type>DoublyLinkedList
{
public:
    void insertAtFront(Type data)
    {
        Node<Type>* newNode = new newNode;
        newNode->setData(data);
        head->setPrev(newNode);
        newNode->setNext(head);
        newNode->setPrev(NULL);
        head = mewNode;
    }
	void insertAtEnd(Type data)
	{
	    Node<Type>* newNode = new newNode;
        newNode->setData(data);
        tail->setNext(newNode);
        newNode->setPrev(tail);
        newNode->setNext(NULL);
        tail = mewNode;
	}
	Type removeFromFront()
	{
	    Node<Type>* temp1;
	    Node<Type>* temp2;
	    temp1 = temp2 = head;
	    head=head->getNext();
	    delete temp1;
	    return temp2;
	}
	Type removeFromEnd()
	{
	    Node<Type>* temp1;
	    Node<Type>* temp2;
	    temp1 = temp2 = tail;
	    tail=tail->getPrev();
	    delete temp1;
	    return temp2;
	}
	void display()
	{
        cout<<"List = ";
        Node<Type>* temp = head;
        while(temp->getNext() != NULL)
        {
            cout<<temp->getData()<< " ";
            temp = temp->getNext();
        }
        cout<<endl;
	}
};