#include "DoublyLinkedList.h"

template <class Type>
class Queue
{
public:
	void EnQueue(Type data)
	{
	    Node<Type>* newNode = new newNode;
        newNode->setData(data);
        tail->setNext(newNode);
        newNode->setPrev(tail);
        newNode->setNext(NULL);
        tail = mewNode;
	}
	Type DeQueue()
	{
	    Node<Type>* temp1;
	    Node<Type>* temp2;
	    temp1 = temp2 = head;
	    head=head->getNext();
	    delete temp1;
	    return temp2;
	}
	void display()
	{
        cout<<"Queue = ";
        Node<Type>* temp = head;
        while(temp->getNext() != NULL)
        {
            cout<<temp->getData()<< "->";
            temp = temp->getNext();
        }
        cout<<endl;
	}
};