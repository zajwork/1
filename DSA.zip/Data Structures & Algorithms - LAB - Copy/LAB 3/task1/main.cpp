#include <iostream>
using namespace std;

#include "Stack.h"

int main()
{
	int instruction;

	Stack <char>s;
	char data;
	bool indication;

	cout << "Welcome to Stack!!" << endl << endl;

	while (1)
	{
		cout << "Enter 1 to push!" << endl;
		cout << "Enter 2 to pop!" << endl;
		cout << "Enter 3 to check Stack full or not!" << endl;
		cout << "Enter 4 to check Stack empty or not!" << endl;
		cout << "Enter 5 to check size of Stack!" << endl;
		cout << "Enter 6 to display Stack!" << endl;
		cout << "Enter 0 to Exit!" << endl;
		cout << "Enter your instruction : ";
		cin >> instruction;

		if (instruction == 0)
		{
			cout << endl << "Closing Stack" << endl << endl;
			break;
		}

		else if (instruction == 1)
		{
			cout << endl << "Enter character you want to insert : ";
			cin >> data;
			cout << endl;
			s.push(data);
		}

		else if (instruction == 2)
		{
			s.pop();
			cout << endl << "Data Deleted!" << endl << endl;
		}

		else if (instruction == 3)
		{
			indication = s.isFull();
			if (indication == true)
			{
				cout << endl << "Stack is FULL!" << endl << endl;
			}
			else
			{
				cout << endl << "Stack NOT FULL!" << endl << endl;
			}
		}

		else if (instruction == 4)
		{
			indication = s.isEmpty();
			if (indication == true)
			{
				cout << endl << "Stack is EMPTY!" << endl << endl;
			}
			else
			{
				cout << endl << "Stack NOT EMPTY!" << endl << endl;
			}
		}

		else if (instruction == 5)
		{
			cout << endl << "Size of Stack = " << s.count() << endl << endl;
		}

		else if (instruction == 6)
		{
			s.display();
		}

		else
		{
			cout << endl << "Invalid Instruction! Enter your instruction again!" << endl << endl;
		}
	}

	return 0;
}