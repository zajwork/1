#include <iostream>
using namespace std;

template <class T>
class Stack
{
private:
	T *arr;
	int size;
	int current;
public:
	Stack()
	{
		size = 5;
		arr = new T[size];
		current = -1;
	}

	bool isFull()
	{
		if (current + 1 == size)
		{
			return true;
		}
		return false;
	}
	void push(T data)
	{
		if (!isFull())
		{
			current++;
			arr[current] = data;
		}
		else
		{
			T *temp = new T[size * 2];
			for (int i = 0; i<size; i++)
			{
				temp[i] = arr[i];
			}
			size = size * 2;
			delete[]arr;
			arr = temp;

			push(data);
		}
	}
	int count()
	{
		return current + 1;
	}

	bool isEmpty()
	{
		if (current == -1)
		{
			return true;
		}
		return false;
	}

	T pop()
	{
		if (isEmpty())
			return -1;
		T temp;
		temp = arr[current];
		current--;
		return temp;
	}

	void display()
	{
		cout << endl << "Stack = ";
		for (int i = 0; i < current + 1; i++)
		{
			cout << arr[i] << " ";
		}
		cout << endl << endl;
	}

	~Stack()
	{
		delete[]arr;

	}
};

