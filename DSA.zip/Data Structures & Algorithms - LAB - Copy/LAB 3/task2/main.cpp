#include <iostream>
#include <string>
using namespace std;

#include "Stack.h"

int main()
{
	string expression, operators, temp;

	Stack <char>e;
	Stack <char>o;

	cout << "Enter Infix Expression : ";
	cin >> temp;
	
	for (int i = 0; temp[i] != '\0'; i++)
	{
		if (temp[i] == '*' || temp[i] == '/')
		{
			o.push(temp[i]);
		}
		else if (temp[i] == '+' || temp[i] == '-')
		{
			while (o.top() == '*' || o.top() == '/')
			{
				e.push(o.top());
				o.pop();
			}
			
			if (o.top() != '*' && o.top() != '/')
			{
				o.push(temp[i]);
			}
		}
		else if (temp[i] >= '0' &&temp[i] <= '9')
		{
			e.push(temp[i]);
		}
		else if (temp[i] == '(')
		{
			o.push(temp[i]);
		}
		else if (temp[i] == ')')
		{
			while (o.top() != '(')
			{
				e.push(o.top());
				o.pop();
			}
			if (o.top() == '(')
			{
				o.pop();
			}
		}
	}

	while (!o.isEmpty())
	{
		e.push(o.top());
		o.pop();
	}

	cout << "Postfix Expression : ";
	e.display();

	system("pause");
	return 0;
}