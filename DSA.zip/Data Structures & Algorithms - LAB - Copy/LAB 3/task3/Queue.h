#include <iostream>
using namespace std;

template <class T>
class Queue
{
private:
	T *q;
	int front;
	int rear;
	int size;
public:
	Queue()
	{
		size = 5;
		front = rear = -1;
		q = new T[size];
	}
	bool isEmpty()
	{
		if (front == -1 && rear == -1)
			return true;
		return false;
	}

	bool isFull()
	{
		if (rear + 1 == size)
			return true;
		return false;
	}

	void enqueue(T data)
	{
		if (!isFull())
		{
			if (front == -1)
			{
				front = 0;
			}

			rear++;
			q[rear] = data;
		}
		else
		{
			T *temp = new T[size * 2];
			for (int i = 0; i <= rear; i++)
				temp[i] = q[i];

			delete[]q;
			q = temp;
			size *= 2;
			enqueue(data);
		}
	}

	void display()
	{
		if (!isEmpty())
		{
			for (int i = front; i <= rear; i++)
			{
				cout << q[i] << "->";
			}
		}
		else
		{
			cout << "Queue is empty" << endl;
		}
	}

	T dequeue()
	{
		if (isEmpty())
		{
			cout << "Queue is empty" << endl;
			return 0;
		}
		else
		{
			T temp = q[front];
			if (front == rear)
			{
				front = rear = -1;
			}
			else
			{
				for (int i = front; i<rear; i++)
				{
					q[i] = q[i + 1];
				}
				rear--;
			}
			return temp;
		}
	}

};