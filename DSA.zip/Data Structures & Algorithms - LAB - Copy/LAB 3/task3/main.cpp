#include <iostream>
using namespace std;

#include "Queue.h"

int main()
{
	int instruction;

	Queue <int>q;
	char data;
	bool indication;

	cout << "Welcome to Queue!!" << endl << endl;

	while (1)
	{
		cout << "Enter 1 to enqueue!" << endl;
		cout << "Enter 2 to dequeue!" << endl;
		cout << "Enter 3 to check Queue full or not!" << endl;
		cout << "Enter 4 to check Queue empty or not!" << endl;
		cout << "Enter 5 to show Queue!" << endl;
		cout << "Enter 0 to Exit!" << endl;
		cout << "Enter your instruction : ";
		cin >> instruction;

		if (instruction == 0)
		{
			cout << endl << "Closing Queue" << endl << endl;
			break;
		}

		else if (instruction == 1)
		{
			cout << endl << "Enter character you want to insert : ";
			cin >> data;
			cout << endl;
			q.enqueue(data);
		}

		else if (instruction == 2)
		{
			q.dequeue();
			cout << endl << "Data Deleted!" << endl << endl;
		}

		else if (instruction == 3)
		{
			indication = q.isFull();
			if (indication == true)
			{
				cout << endl << "Queue is FULL!" << endl << endl;
			}
			else
			{
				cout << endl << "Queue NOT FULL!" << endl << endl;
			}
		}

		else if (instruction == 4)
		{
			indication = q.isEmpty();
			if (indication == true)
			{
				cout << endl << "Queue is EMPTY!" << endl << endl;
			}
			else
			{
				cout << endl << "Queue NOT EMPTY!" << endl << endl;
			}
		}

		else if (instruction == 5)
		{
			q.display();
		}

		else
		{
			cout << endl << "Invalid Instruction! Enter your instruction again!" << endl << endl;
		}
	}

	return 0;
}