#include <iostream>

using namespace std;
template<class T>
class Node{
public:
	T data;
	Node*next, *prev;
};
template<class T>
class DLL{
private:
	Node<T>*head;
	Node<T>*tail;
public:
	int s = 0;
	DLL()
	{
		head = tail = NULL;
	}
	void insertatend(T data)
	{
		Node<T>*ik = new Node<T>;
		ik->data = data;
		ik->next = NULL;
		ik->prev = NULL;
		if (head == NULL)
		{
			head = ik;
			tail = ik;
		}
		else
		{
			tail->next = ik;
			ik->prev = tail;
			tail = tail->next;
		}
	}
	void swap(int key)
	{

		Node<T>*temp = head;
		Node<T>*temp1 = tail;
		while(temp != NULL)
		{
			if (temp1 != NULL)
			{
				s++;
				if (key == s)
				{
					T junk = temp->data;
					temp->data = temp1->data;
					temp1->data = junk;
					break;
				}
				temp1 = temp1->prev;
			}
			else
			{
				break;
			}
			temp = temp->next;
		}
	}
	void display()
	{
		Node<T>*temp = head;
		while (temp!=NULL)
			{
			cout << temp->data << " ";
			temp = temp->next;
		}
	}




};
int main()
{
	DLL <int>obj;
	obj.insertatend(1);
	obj.insertatend(2);
	obj.insertatend(3);
	obj.insertatend(4);
	obj.insertatend(5);
	obj.insertatend(6);
	obj.insertatend(7);
	obj.insertatend(8);
	cout << "before swap list" << endl;
	obj.display();
	obj.swap(3);

	cout << "\n after swap list" << endl;
	obj.display();
	system("pause");
	return 0;
}
