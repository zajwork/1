#include "LinkedList.h"

int main()
{
	LinkedList l;

	cout << l.empty() << endl;
	l.insertAtStart(4.0);
	l.insertAtEnd(2.5);
	l.insertAtEnd(3.5);
	cout << l.size() << endl;

	l.display();
	cout << endl;
	cout << l.front() << endl;
	cout << l.back() << endl;

	system("pause");
	return 0;
}