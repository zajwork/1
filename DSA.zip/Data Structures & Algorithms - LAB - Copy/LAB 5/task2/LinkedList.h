#include "Node.h"

class LinkedList
{
private:
	Node *head;
	Node *tail;
public:
	LinkedList()
	{
		head = NULL;
		tail = NULL;
	}
	void insertAtStart(float data)
	{
		Node *N = new Node();
		N->setData(data);
		N->setNext(head);
		if (head == NULL)
		{
			tail = N;
		}
		head = N;
	}
	void insertAtEnd(float data)
	{
		Node *t = new Node;
		t->setData(data);
		t->setNext(NULL);

		if (head == NULL)
		{
			head = t;
			tail = t;
		}
		else
		{
			tail->setNext(t);
			tail = t;
		}

	}

	void removeFromStart()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else if (head == tail)
		{
			delete head;
			head = tail = NULL;
		}
		else
		{
			Node* temp = head;
			head = head->getNext();
			delete temp;
		}
	}

	void deleteFromEnd()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else if (head == tail)
		{
			delete head;
			head = tail = NULL;
		}
		else
		{
			Node *temp = head;
			while (temp->getNext() != tail)
			{
				temp = temp->getNext();
			}

			tail = temp;

			temp = temp->getNext();
			delete temp;
			tail->setNext(NULL);
		}
	}

	float front()
	{
		return head->getData();
	}

	float back()
	{
		return tail->getData();
	}

	bool empty()
	{
		if (head == NULL)
		{
			return true;
		}
		return false;
	}

	int size()
	{
		Node *temp = head;
		int count = 0;
		while (temp != NULL)
		{
			temp = temp->getNext();
			count++;
		}
		return count;
	}

	void display()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;
			while (temp != NULL)
			{
				cout << temp->getData() << "->";
				temp = temp->getNext();
			}
		}
	}
};