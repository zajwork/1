#include <iostream>
using namespace std;

template <class Type>
class Node
{
public:
	Type key;
	Node<Type>* leftChild;
	Node<Type>* rightChild;
	Node()
	{
	    key = NULL;
		leftChild = NULL;
		rightChild = NULL;
	}
};

template <class Type>
class Tree : public Node<Type>
{
public:
    Node<Type>* root;
	Tree()
	{
	    this->root = NULL;
	};
	virtual Node<Type>* insert(Type) = 0;
	virtual bool searchNode(Type) = 0;  
};

template <class Type>
class BST : public Tree<Type>
{
public:
	BST()
	{
		//this->root = NULL;

	}
	Node<Type>* createRoot(Type data)
	{
		if (this->root == NULL)
		{
			this->root->key = data;
		}
		else
		{
			cout << "Root already exist!" << endl;
		}
		return this->root;
	}
	Node<Type>* insert(Type data)
	{
		if (this->root == NULL)
		{
			createRoot(data);
		}
		else
		{
			Node<Type>* temp = new Node<Type>;
			temp = this->root;
			while (true)
			{
				if (data > temp->key)
				{
					if (temp->rightChild == NULL)
					{
						temp->rightChild->key = data;
						break;
					}
					else
					{
						temp = temp->rightChild;
					}
				}
				else 
				{
					if (temp->leftChild == NULL)
					{
						temp->leftChild->key = data;
						break;
					}
					else
					{
						temp = temp->leftChild;
					}
				}
			}
		}
		return this->root;
	}
	bool searchNode(Type data)
	{
		return false;
	}
	void preOrderTraversal()
	{
	    Node<Type>* temp = new Node<Type>;
		temp = this->root;
		if (temp == NULL)
			return;

		cout << temp->data << "  ";
		preOrderTraversal(temp->left);
		preOrderTraversal(temp->right);
	}
	void InOrderTraversal()
	{
        Node<Type>* temp = new Node<Type>;
		temp = this->root;
		if (temp == NULL)
			return;
		preOrderTraversal(temp->left);
		cout << temp->data << "  ";
		preOrderTraversal(temp->right);
	}
	void postOrderTraversal()
	{
        Node<Type>* temp = new Node<Type>;
		temp = this->root;
		if (temp == NULL)
			return;
		preOrderTraversal(temp->left);
		preOrderTraversal(temp->right);
		cout << temp->data << "  ";
	}
	~BST()
	{

	}
};


int main()
{
	BST<char> tree; 
	tree.createRoot('h');
	tree.createRoot('4');
	tree.InOrderTraversal();

	system("pause");
	return 0;
}