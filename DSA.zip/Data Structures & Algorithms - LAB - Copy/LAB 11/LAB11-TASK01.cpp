#include <iostream>
using namespace std;

class Node
{
public:
	float data;
	Node *next;
};

class LinkedList
{
private:
	Node *head;
	Node *tail;
public:
	LinkedList()
	{
		head = NULL;
		tail = NULL;
	}
	void insertAtStart(float data)
	{
		Node *N = new Node();
		N->data = data;
		N->next = head;
		if (head == NULL)
		{
			tail = N;
		}
		head = N;
	}
	void insertAtEnd(float data)
	{
		Node *t = new Node;
		t->data = data;
		t->next = NULL;

		if (head == NULL)
		{
			head = t;
			tail = t;
		}
		else
		{
			tail->next = t;
			tail = t;
		}

	}

	void removeFromStart()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else if (head == tail)
		{
			delete head;
			head = tail = NULL;
		}
		else
		{
			Node* temp = head;
			head = head->next;
			delete temp;
		}
	}

	void deleteFromEnd()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else if (head == tail)
		{
			delete head;
			head = tail = NULL;
		}
		else
		{
			Node *temp = head;
			while (temp->next != tail)
			{
				temp = temp->next;
			}

			tail = temp;

			temp = temp->next;
			delete temp;
			tail->next = NULL;
		}
	}

	void display()
	{
		if (head == NULL)
		{
			cout << "List is empty" << endl;
		}
		else
		{
			Node *temp = head;
			while (temp != NULL)
			{
				cout << temp->data << "->";
				temp = temp->next;
			}
		}
	}

	Node* getHead()
	{
		return head;
	}

	void reverse(Node* N)
	{
		if (N == NULL)
			return;
		reverse(N->next);
		cout << N->data << "->";
	}

};

int main()
{
	LinkedList ll;
	ll.insertAtStart(1);
	ll.insertAtEnd(2);
	ll.insertAtEnd(3);
	ll.insertAtEnd(4);
	ll.insertAtEnd(5);
	cout << "Linked List  = ";
	ll.display();
	cout << endl;

	cout << "Reverse List = ";
	ll.reverse(ll.getHead());
	cout << endl;

	system("pause");
	return 0;
}