#include <iostream>
using namespace std;

int Factorial(int i)
{
	if (i == 0 || i == 1)
	{
		return 1;
	}
	return i * Factorial(i - 1);
}

int main()
{
	cout << Factorial(9);

	system("pause");
	return 0;
}