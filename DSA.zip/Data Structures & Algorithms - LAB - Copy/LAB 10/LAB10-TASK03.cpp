#include <iostream>
using namespace std;

int Qseries(int i)
{
	if (i == 13)
	{
		return Qseries(i) + Qseries(i + 1);
	}
	
	cout << 0;
}

int main()
{
	cout << Qseries(0);

	system("pause");
	return 0;
}