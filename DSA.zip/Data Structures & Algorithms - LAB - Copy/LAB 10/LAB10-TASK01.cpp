#include <iostream>
using namespace std;

template <class T>
class BT
{
private:
	T *tree;
	int currentSize;
public:
	BT()
	{
		currentSize = 15;
		tree = new T[currentSize];
	}
	void Insert_root(T key)
	{
		if (tree[0] != '\0')
		{
			tree[0] = key;
		}
		else
		{
			cout << "Root already exists!" << endl;
		}
	}
	void Insert_left_node(T key, int parent)
	{
		if (tree[parent] != '\0')
		{
			tree[(parent*2) + 1] = key;
		}
		else
		{
			cout << "parent does not exist!" << endl;
		}
	}
	void Insert_right_node(T key, int parent)
	{
		if (tree[parent] != '\0')
		{
			tree[(parent*2) + 2] = key;
		}
		else
		{
			cout << "parent does not exist!" << endl;
		}
	}
	void Print_tree()
	{
		for (int i = 0; i < currentSize; i++)
		{
			if (tree[i] != '\0')
			{
				cout << tree[i] << " ";
			}
		}
		cout << endl;
	}
	void Search(T key)
	{
		for (int i = 0; i < currentSize; i++)
		{
			if (tree[i] == key)
			{
				cout << "Key found!" << endl;
				break;
			}
		}
		cout << endl;
	}
	void Delete_leaf()
	{

	}
	~BT()
	{
		delete tree;
	}

};

int main()
{
	BT <char> b;
	b.Insert_root('6');
	b.Insert_left_node('5', 0);
	b.Insert_right_node('9', 0);
	b.Print_tree();

	system("pause");
	return 0; 
}