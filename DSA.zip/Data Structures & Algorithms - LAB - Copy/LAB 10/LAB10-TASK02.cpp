#include <iostream>
using namespace std;

int sum(int i)
{
	if (i == 0 || i == 1)
	{
		return i;
	}
	return i%10 + sum(i/10);
}

int main()
{
	cout << sum(267);

	system("pause");
	return 0;
}