#include <iostream>
using namespace std;

#include "CircularQueue.h"

template <class Type>
class MyCircularQueue : public CircularQueue<Type>
{
public:

	MyCircularQueue()
	{
		front = -1;
		rear = -1;
		maxSize = 10;
		arr = new Type[maxSize];
	}

	bool empty()
	{
		if (front == rear)
		{
			return true;
		}
		return false;
	}

	bool full()
	{
		if (front - rear == -1 || (front == 0 && rear = size - 1))
		{
			return true
		}
		return false;
	}

	int size()
	{
		if (rear >= front)
		{
			return(maxSize - 1 - rear + front);
		}
		else
		{
			return (front - rear);
		}
	}

	Type front()
	{
		return arr[front];
	}

	void enqueue(Type data)
	{
		if (!isFull())
		{
			if (rear >= front && rear < maxSize - 1)
			{
				rear++;
				data[rear];
			}
			else if (front > rear && rear == maxSize - 1)
			{
				rear = 0;
				arr[rear];
			}
			else
			{
				rear++;
				arr[rear];
			}
		}
		else
		{
			cout << "Queue is Full! Unable to add data!" << endl;
			return -111;
		}
	}

	Type dequeue()
	{
		if (!isEmpty())
		{
			if (rear <= front && front < maxSize)
			{
				front++;
				return data[front - 1];
			}
			else if (front > rear && front == maxSize - 1)
			{
				front = 0;
				return arr[maxSize - 1];
			}
			else
			{
				front++;
				return data[front - 1];
			}
		}
		else
		{
			cout << "Queue is Empty! Unable to remove data!" << endl;
			return -111;
		}

	}

	void show()
	{
		cout << "Queue = ";
		if (front <= rear)
		{

			for (int i = front; i <= rear; i++)
			{
				cout << arr[i] << "->";
			}
			cout << endl;
		}
		else
		{
			for (int i = front; i < maxSize; i++)
			{
				cout << arr[i] << "->";
			}
			for (int i = 0; i <= rear; i++)
			{
				cout << arr[i] << "->";
			}
			cout << endl;
		}
	}

	~MyCircularQueue()
	{
		delete[]arr;
	}

};
