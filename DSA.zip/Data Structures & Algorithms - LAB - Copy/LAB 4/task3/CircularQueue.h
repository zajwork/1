template <class Type>
class CircularQueue
{
protected:
	Type* arr;
	int front;
	int rear;
	int maxSize;
	virtual void enqueue(Type) = 0;
	virtual Type dequeue() = 0;
	CircularQueue(){};
};