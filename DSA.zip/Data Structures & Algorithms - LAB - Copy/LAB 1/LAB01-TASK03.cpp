#include <iostream>
using namespace std;

template <class T>
class Array
{
	int size;
	T* data;
public:
	Array()
	{
		size = 1;
		data = new T[1];
		data[0] = '\0';
	}
	Array(T d[], int s)
	{
		size = s + 1;
		data = new T[size];
		for (int i = 0; i < s; i++)
		{
			data[i] = d[i];
		}
		data[s] = '\0';
	}

	void InsertAtBegin(T a)
	{
		T* temp = new T[size];
		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i];
		}

		size++;
		data = new T[size];

		data[0] = a;

		for (int i = 0; i < size; i++)
		{
			data[i + 1] = temp[i];
		}

		temp = NULL;
		delete[]temp;
	}

	void InsertAtEnd(T a)
	{
		T* temp = new T[size];
		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i];
		}

		size++;
		data = new T[size];

		for (int i = 0; i < size; i++)
		{
			data[i] = temp[i];
		}

		data[size - 2] = a;
		data[size - 1] = '\0';

		temp = NULL;
		delete[]temp;
	}

	void DeleteFromBegin()
	{
		T* temp = new T[size - 1];
		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i + 1];
		}

		size--;
		data = new T[size];

		for (int i = 0; i < size; i++)
		{
			data[i] = temp[i];
		}

		temp = NULL;
		delete[]temp;

	}

	void DeleteFromEnd()
	{
		size--;
		T* temp = new T[size];
		for (int i = 0; i < size - 1; i++)
		{
			temp[i] = data[i];
		}

		data = new T[size];

		for (int i = 0; i < size; i++)
		{
			data[i] = temp[i];
		}

		data[size - 1] = '\0';

		temp = NULL;
		delete[]temp;

	}

	void Delete()
	{
		size = 1;
		data = new T[size];
		data[0] = '\0';
	}

	void InsetAfter(T input, int index)
	{
		T *temp = new T[size];

		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i];
		}

		size++;
		data = new T[size];

		for (int i = 0; i < index; i++)
		{
			data[i] = temp[i];
		}

		data[index] = input;

		for (int i = index; i < size; i++)
		{
			data[i + 1] = temp[i];
		}

		temp = NULL;
		delete[]temp;
	}

	T Max()
	{
		T max = data[0];

		for (int i = 1; i < size; i++)
		{
			if (data[i]>max)
			{
				max = data[i];
			}
		}
		return max;
	}

	void ReverseList()
	{
		T* temp = new T[size];

		for (int i = 0, j = size - 2; j >= 0; i++, j--)
		{
			temp[i] = data[j];
		}
		temp[size - 1] = '\0';
		
		for (int i = 0; i < size; i++)
		{
			data[i] = temp[i];
		}

		temp = NULL;
		delete[]temp;
	}

	void ReSizeList(T input[], int resize)
	{
		T* temp = new T[size];

		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i];
		}

		size = size + resize;
		data = new T[size];

		for (int i = 0; i < size - 1 - resize; i++)
		{
			data[i] = temp[i];
		}

		for (int i = size - resize - 1, j = 0; i < size - 1; i++, j++)
		{
			data[i] = input[j];
		}
		data[size - 1] = '\0';
		
		temp = NULL;
		delete[]temp;
	}

	void displayArray()
	{
		cout << "Data of Array : ";
		for (int i = 0; i < size; i++)
		{
			cout << data[i] << " ";
		}
		cout << endl;
	}
};


int main()
{
	char arr[9] = { 'a', '2', '3', 'h', '5', '6', 'g', '8', '9' };

	cout << "Hard-codded array!" << endl << endl;

	Array<char> a(arr, 9);
	a.displayArray();

	cout << "After inserting at start" << endl;
	a.InsertAtBegin('8');
	a.displayArray();

	cout << "After inserting at end" << endl;
	a.InsertAtEnd('j');
	a.displayArray();

	cout << "After deleting from start" << endl;
	a.DeleteFromBegin();
	a.displayArray();

	cout << "After deleting end" << endl;
	a.DeleteFromEnd();
	a.displayArray();

	cout << "After inserting after a index" << endl;
	a.InsetAfter('k', 3);
	a.displayArray();

	cout << "Max value of array = " << a.Max() << endl;
	
	cout << "After reveresing list" << endl;
	a.ReverseList();
	a.displayArray();


	char resize[3] = { '9', 'g', 'm' };
	cout << "After re-size" << endl;
	a.ReSizeList(resize, 3);
	a.displayArray();

	cout << "After deleting" << endl;
	a.Delete();
	a.displayArray();

	system("pause");
	return 0;
}