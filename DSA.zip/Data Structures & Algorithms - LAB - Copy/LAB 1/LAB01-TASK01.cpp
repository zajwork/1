#include <iostream>
using namespace std;

class IntArray
{
public:
	// operations performed on arrays 
	IntArray (int size);
	~IntArray();
	int getValue(int index);
	void setValue(int index, int value); int getSize();
protected:
	void checkBounds(int index);

	// internal data representation
	int size; 
	int *data;
};

IntArray::IntArray(int sz) 
{
	// allocate an integer array of 'size' elements.
	// new returns a pointer to this array or 0
	// 0 indicates the program has exhausted its
	// available memory: a generally fatal error size = sz;
	data = new int[size];

	for (int ix = 0; ix < sz; ix++) 
		data[ix] = 0;
}

void IntArray::checkBounds(int index) 
{
	if (index < 0) 
	{
		cout << "An array index is out of bounds. Its value is" << index << endl; exit(1);
	}
	if (index >= size) 
	{
		cout << "An array index exceeds the bounds of its array. The size";
		cout << "of the array is" << size << " but the value of the index is" << index << endl; exit(1);
	}
}

int IntArray::getValue(int index) 
{
	checkBounds(index);
	return data[index];
}

void IntArray::setValue(int index, int value) 
{
	checkBounds(index);
	data[index] = value;
}

int IntArray::getSize() 
{ 
	return size; 
}

IntArray::~IntArray()
{ 
	delete[] data; 
}

int main()
{

	system("pause");
	return 0;
}
