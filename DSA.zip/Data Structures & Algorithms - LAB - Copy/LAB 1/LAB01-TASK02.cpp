#include <iostream>
using namespace std;

template <class T>
class Array
{
public:
	// operations performed on arrays 
	Array(int size);
	~Array();
	T getValue(int index);
	void setValue(int index, T value);
	int getSize();
protected:
	void checkBounds(int index);

	// internal data representation
	int size;
	T *data;
};

template <typename T>
Array<T>::Array(int size)
{
	// allocate an integer array of 'size' elements.
	// new returns a pointer to this array or 0
	// 0 indicates the program has exhausted its
	// available memory: a generally fatal error size = sz;
	data = new T[size];

	for (int ix = 0; ix < size; ix++)
		data[ix] = 0;
}

template <typename T>
void Array<T>::checkBounds(int index)
{
	if (index < 0)
	{
		cout << "An array index is out of bounds. Its value is" << index << endl; exit(1);
	}
	if (index >= size)
	{
		cout << "An array index exceeds the bounds of its array. The size";
		cout << "of the array is" << size << " but the value of the index is" << index << endl; exit(1);
	}
}

template <typename T>
T Array<T>::getValue(int index)
{
	checkBounds(index);
	return data[index];
}

template <typename T>
void Array<T>::setValue(int index, T value)
{
	checkBounds(index);
	data[index] = value;
}

template <typename T>
int Array<T>::getSize()
{
	return size;
}

template <typename T>
Array<T>::~Array()
{
	delete[] data;
}

int main()
{
	Array<int> arr(2);

	system("pause");
	return 0;
}
