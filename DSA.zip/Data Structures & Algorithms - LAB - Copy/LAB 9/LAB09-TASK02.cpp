#include<iostream>
using namespace std;

int Sum(int *arr, int size)
{
	if (size == -1)
	{
		return 0;
	}
	return arr[size] + Sum(arr, size - 1);

}

int Product(int *arr, int size)
{
    if (size == -1)
	{
        return 1;
	}
	return arr[size] * Product(arr, size - 1);
}

int main()
{
	int *array;
	int size;
	cout << "Enter size of array : " << endl;
	cin >> size;
	array = new int[size];
	cout << "Enter elements of array : " <<endl;
	for (int i = 0; i < size; i++)
	{
		cin >> array[i];
	}
	cout << "Sum = " << Sum(array, size) << endl;
	cout << "Product = " << Product(array, size) << endl;
	
	return 0;
}