#include <iostream>

using namespace std;

int Reverse(int arr[], int start, int end) 
{
    int temp;
    
    if(start < end) 
    {
        temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        
        Reverse(arr, start+1, end-1);
    }
    
    return 0;
}

int main() 
{
    int size;
    
    cout << "Enter the size of an array :"<<endl;
    cin  >> size;
    
    int* arr = new int[size];
    
    cout << "Enter an element of an array \n";
    
    for(int i = 0; i < n; i++) 
    {
        cin >> arr[i];
    }
    
    reverse(arr, 0, n-1);
    
    cout << "Reverse of an array is : " <<endl;
    
    for(i = 0; i < n; i++) 
    {
        cout << arr[i] << " ";
    }
    
    return 0;
}
