#include <iostream>
#include <string>
using namespace std;

class Stack
{
	int tempSize = 0;
	int size = 0;
	string parenthesis;
	char* temp;
public:
	Stack()
	{
		size = 0;
	}
	char* regrow(char* arr)
	{
		temp = new char[tempSize + 1];
		for (int i = 0; i < tempSize; i++)
		{
			temp[i] = arr[i];
		}
		return temp;
	}
	char* shrink(char* arr)
	{
		temp = new char[tempSize - 1];
		for (int i = 0; i < tempSize - 1; i++)
		{
			temp[i] = arr[i];
		}
		return temp;
	}
	void checkParenthesis(string p)
	{
		parenthesis = p;
		pop();
		while (true)
		{
			if (parenthesis[size] == temp[tempSize-1])
			{
				pop();
			}
			else
			{
				push();
			}
			if (parenthesis[size] == '\0')
				break;
		}
		if (tempSize == 0)
		{
			cout << "True" << endl;
		}
		else
			cout << "False" << endl;
	}
	void push()
	{
		if (parenthesis[size] != '\0')
		{
			temp = regrow(temp);
			temp[tempSize] = parenthesis[size];
			tempSize++;
			size++;
		}
	}
	void pop()
	{
		temp = shrink(temp);
		tempSize--;
		size++;
	}
};

int main()
{

	system("pause");
	return 0;
}