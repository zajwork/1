#include <iostream>
using namespace std;

#include "Stack.h"

int main()
{
	Stack<int> st;


	system("pause");
	return 0;
}






