#include <iostream>
using namespace std;

#include "List.h"

template<class Type>
class Stack : public List<Type>
{
public:
	Stack()
	{
		maxSize = 10;
		currentSize = 0;
	}
	Stack(Stack& s)
	{
		currentSize = s.currentSize;
		arr = new Type[currentSize];

		for (int i = 0; i<currentSize; i++)
		{
			arr[i] = s.arr[i];
		}
	}
	bool empty()
	{
		if (currentSize == 0)
		{
			return true;
		}
		return false;
	}
	bool full()
	{
		if (currentSize == maxSize)
		{
			return true;
		}
		return false;
	}
	int size()
	{
		return currentSize;
	}
	Type top()
	{
		return arr[currentSize];
	}
	void push(Type element)
	{
		arr = regrow();
		arr[currentSize] = element;
	}
	virtual Type* removeElement()
	{
		currentSize--;
		Type* temp = new Type[currentSize];
		for (int i = 0; i<currentSize; i++)
		{
			temp[i] = arr[i];
		}
		return temp;
	}
	virtual void addElement(Type element)
	{
		push(element);
	}
	Type pop()
	{
		arr = removeElement();
	}
	~Stack()
	{
		arr = NULL;
		delete[]arr;

	}
};