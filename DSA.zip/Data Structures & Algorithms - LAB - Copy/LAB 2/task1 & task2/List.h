#include <iostream>
using namespace std;

template <class Type>
class List
{
protected:
	Type* arr;
	int maxSize;
	int currentSize;
	Type* regrow()
	{
		currentSize++;
		Type* temp = new Type[currentSize];
		for (int i = 0; i < currentSize; i++)
		{
			temp[i] = arr[i];
		}

		return temp;
	}
public:
	virtual void addElement(Type) = 0;
	virtual Type* removeElement() = 0;
};



